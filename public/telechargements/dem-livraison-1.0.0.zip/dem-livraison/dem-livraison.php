<?php
/**
 * Plugin Name:       DEM Livraison pour WooCommerce
 * Plugin URI:        https://www.dem.sn/developpeurs
 * Description:       Livraison DEM à Dakar : prix affiché au panier, livraison créée automatiquement au paiement, suivi et statuts mis à jour tout seuls.
 * Version:           1.0.0
 * Author:            DEM — Delivery Express Mobility
 * Author URI:        https://www.dem.sn
 * Text Domain:       dem-livraison
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Requires Plugins:  woocommerce
 * WC requires at least: 7.0
 * WC tested up to:   11.2
 * License:           GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

define( 'DEM_LIVRAISON_VERSION', '1.0.0' );
define( 'DEM_LIVRAISON_FILE', __FILE__ );
define( 'DEM_LIVRAISON_DIR', plugin_dir_path( __FILE__ ) );

// Compatible avec le stockage des commandes HPOS et le panier en blocs
add_action( 'before_woocommerce_init', function () {
	if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, true );
	}
} );

add_action( 'plugins_loaded', function () {
	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', function () {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'DEM Livraison a besoin de WooCommerce pour fonctionner.', 'dem-livraison' ) . '</p></div>';
		} );
		return;
	}

	require_once DEM_LIVRAISON_DIR . 'includes/class-dem-api.php';
	require_once DEM_LIVRAISON_DIR . 'includes/class-dem-settings.php';
	require_once DEM_LIVRAISON_DIR . 'includes/class-dem-orders.php';
	require_once DEM_LIVRAISON_DIR . 'includes/class-dem-webhook.php';

	DEM_Livraison_Settings::init();
	DEM_Livraison_Orders::init();
	DEM_Livraison_Webhook::init();

	// Mode de livraison : chargé quand WooCommerce prépare les livraisons
	add_action( 'woocommerce_shipping_init', function () {
		require_once DEM_LIVRAISON_DIR . 'includes/class-dem-shipping.php';
	} );
	add_filter( 'woocommerce_shipping_methods', function ( $methods ) {
		$methods['dem_livraison'] = 'DEM_Livraison_Shipping';
		return $methods;
	} );

	add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $links ) {
		$url = admin_url( 'admin.php?page=wc-settings&tab=dem_livraison' );
		array_unshift( $links, '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Réglages', 'dem-livraison' ) . '</a>' );
		return $links;
	} );
} );
