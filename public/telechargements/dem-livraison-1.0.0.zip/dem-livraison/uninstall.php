<?php
/**
 * Suppression du module : réglages effacés. Les informations DEM des
 * commandes (identifiant, statut) sont gardées dans l'historique.
 */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

foreach ( array(
	'dem_livraison_api_key', 'dem_livraison_store_id', 'dem_livraison_store', 'dem_livraison_auto_create',
	'dem_livraison_payment', 'dem_livraison_complete_on_delivered', 'dem_livraison_fallback_price',
	'dem_livraison_debug', 'dem_livraison_webhook_id', 'dem_livraison_webhook_secret',
) as $option ) {
	delete_option( $option );
}
delete_transient( 'dem_livraison_me' );
delete_transient( 'dem_livraison_stores' );
