=== DEM Livraison pour WooCommerce ===
Contributors: dem
Tags: livraison, dakar, sénégal, coursier, woocommerce
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
WC requires at least: 7.0
WC tested up to: 11.2
Stable tag: 1.0.0
License: GPLv2 or later

Livraison DEM à Dakar pour votre boutique WooCommerce : prix au panier, livraison créée toute seule au paiement, suivi en direct.

== Description ==

Branchez votre boutique au réseau de coursiers DEM, sans développeur :

* **Prix DEM au panier** : votre client voit « Livraison DEM — 1 300 F » calculé pour son adresse. Ce prix est garanti 15 minutes.
* **Livraison créée toute seule** dès que la commande est payée (statut « En cours »), ou d'un clic avec le bouton « Envoyer à DEM ».
* **Commande mise à jour à chaque étape** : coursier trouvé, colis récupéré, livrée (la commande passe à « Terminée »).
* **Suivi en direct** : le lien de suivi est ajouté aux e-mails et à l'espace client.
* **Jamais deux livraisons pour une commande**, même si l'envoi est répété ; nouvel essai automatique si DEM est momentanément injoignable.

L'API DEM est incluse dans l'offre DEM Pro Premium. Documentation : https://www.dem.sn/developpeurs

== Installation ==

1. Extensions › Ajouter › Téléverser : choisissez `dem-livraison.zip`, puis Activer.
2. WooCommerce › Réglages › **DEM Livraison** : collez votre clé API (application DEM Pro › Compte › API DEM). Commencez par une clé de Test (`dem_test_…`) : aucune vraie course n'est créée.
3. Cliquez **Brancher les webhooks** (votre boutique doit être en https).
4. WooCommerce › Réglages › Expédition : ajoutez **Livraison DEM** à votre zone de livraison Sénégal.
5. Passez une commande de test, puis remplacez la clé par une clé de Production (`dem_live_…`).

== Questions fréquentes ==

= Qui paie le coursier ? =
Vous, puisque votre client a déjà payé la livraison sur votre site : en espèces au coursier, ou par votre wallet DEM Pro (réglage « Paiement du coursier »).

= Le téléphone du client est refusé ? =
DEM a besoin d'un mobile sénégalais (70, 71, 75, 76, 77, 78) pour que le coursier puisse appeler votre client. Corrigez-le dans la commande puis cliquez « Envoyer à DEM ».

= Où voir ce qui se passe ? =
Dans chaque commande (panneau « Livraison DEM » et notes), et dans WooCommerce › État › Journaux (source « dem-livraison », journal détaillé à activer dans les réglages).

== Changelog ==

= 1.0.0 =
* Première version : prix au panier, création automatique au paiement, bouton manuel, webhooks signés, suivi client, nouvel essai automatique.
