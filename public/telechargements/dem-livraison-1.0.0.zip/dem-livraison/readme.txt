=== DEM Livraison pour WooCommerce ===
Contributors: dem
Tags: livraison, dakar, sénégal, coursier, woocommerce
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
WC requires at least: 7.0
WC tested up to: 11.2
Stable tag: 1.0.0
License: GPLv2 or later

Livraison DEM à Dakar pour votre boutique WooCommerce : prix au panier, livraison créée toute seule au paiement, suivi en direct.

== Description ==

Branchez votre boutique au réseau de coursiers DEM, sans développeur :

* **Prix DEM au panier** : votre client voit « Livraison DEM — 1 300 F » calculé pour son adresse. Ce prix est garanti 15 minutes.
* **Mise en avant** : « Livraison DEM » est en tête des modes de livraison, cochée par défaut et encadrée (« Coursier DEM à domicile · suivi en direct »). Le client garde le choix ; réglage « Mettre DEM en avant ».
* **Livraison créée toute seule** dès que la commande est payée (statut « En cours »), ou d'un clic avec le bouton « Envoyer à DEM ».
* **Commande mise à jour à chaque étape** : coursier trouvé, colis récupéré, livrée (la commande passe à « Terminée »).
* **Suivi en direct** : le lien de suivi est ajouté aux e-mails et à l'espace client.
* **Infos du coursier vérifiées avant le paiement** : téléphone obligatoire, mobile sénégalais exigé avec « Livraison DEM » (sinon la commande n'est pas passée et le client voit pourquoi), champ « Repère » au Sénégal, note du client transmise au coursier.
* **Aucune commande oubliée** : si DEM ne peut pas créer la livraison (adresse introuvable, wallet insuffisant…), vous êtes prévenu par e-mail, par un bandeau dans l'administration et dans la commande, avec quoi faire ; « Envoyer à DEM » une fois corrigé.
* **Jamais deux livraisons pour une commande**, même si l'envoi est répété ; nouvel essai automatique si DEM est momentanément injoignable.

L'API DEM est incluse dans l'offre DEM Pro Premium. Documentation : https://www.dem.sn/developpeurs

== Installation ==

1. Extensions › Ajouter › Téléverser : choisissez `dem-livraison.zip`, puis Activer.
2. WooCommerce › Réglages › **DEM Livraison** : collez votre code de connexion (application DEM Pro › Compte › API DEM › « Brancher mon site » › WooCommerce).
3. Cliquez **Brancher les webhooks** (votre boutique doit être en https).
4. WooCommerce › Réglages › Expédition : ajoutez **Livraison DEM** à votre zone de livraison Sénégal.
5. Pour essayer sans vraie course, un développeur peut utiliser une clé de Test (`dem_test_…`, application DEM Pro › Créer une clé).

== Questions fréquentes ==

= Qui paie le coursier ? =
Vous, puisque votre client a déjà payé la livraison sur votre site : en espèces au coursier, ou par votre wallet DEM Pro (réglage « Paiement du coursier »).

= Le téléphone du client est refusé ? =
DEM a besoin d'un mobile sénégalais (70, 71, 75, 76, 77, 78) pour que le coursier puisse appeler votre client. Corrigez-le dans la commande puis cliquez « Envoyer à DEM ».

= Où voir ce qui se passe ? =
Dans chaque commande (panneau « Livraison DEM » et notes), et dans WooCommerce › État › Journaux (source « dem-livraison », journal détaillé à activer dans les réglages).

== Changelog ==

= 1.0.0 =
* Première version : prix au panier, création automatique au paiement, bouton manuel, webhooks signés, suivi client, nouvel essai automatique.
