<?php
/**
 * « Livraison DEM » mise en avant au panier et au paiement :
 * - placée en tête des modes de livraison et cochée par défaut quand elle
 *   apparaît (le client garde la main : s'il choisit un autre mode, son
 *   choix est respecté) ;
 * - ligne encadrée et sous-titre « Coursier DEM à domicile · suivi en
 *   direct », sur le panier classique comme sur le panier en blocs.
 * Réglage « Mettre DEM en avant » (oui par défaut).
 */

defined( 'ABSPATH' ) || exit;

class DEM_Livraison_Checkout {

	const METHOD_ID = 'dem_livraison';

	public static function init() {
		if ( 'yes' !== get_option( 'dem_livraison_highlight', 'yes' ) ) {
			return;
		}
		add_filter( 'woocommerce_package_rates', array( __CLASS__, 'dem_first' ), 100, 2 );
		add_filter( 'woocommerce_shipping_chosen_method', array( __CLASS__, 'dem_by_default' ), 20, 3 );
		add_action( 'woocommerce_after_shipping_rate', array( __CLASS__, 'subtitle' ), 10, 2 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'styles' ), 20 );
	}

	/** Le tarif est-il celui de DEM ? */
	public static function is_dem( $rate ) {
		$method = is_object( $rate ) && method_exists( $rate, 'get_method_id' ) ? $rate->get_method_id() : (string) $rate;
		return 0 === strpos( $method, self::METHOD_ID );
	}

	/** Livraison DEM en tête de liste (l'ordre des autres modes est gardé). */
	public static function dem_first( $rates, $package ) {
		if ( ! is_array( $rates ) || count( $rates ) < 2 ) {
			return $rates;
		}
		$dem    = array();
		$others = array();
		foreach ( $rates as $id => $rate ) {
			if ( self::is_dem( $rate ) ) {
				$dem[ $id ] = $rate;
			} else {
				$others[ $id ] = $rate;
			}
		}
		return $dem + $others;
	}

	/**
	 * Mode coché par défaut : WooCommerce l'appelle quand il doit choisir à la
	 * place du client (rien de choisi, ou liste des modes changée — par
	 * exemple quand « Livraison DEM » apparaît après la saisie de l'adresse).
	 */
	public static function dem_by_default( $default, $rates, $chosen_method ) {
		if ( ! is_array( $rates ) ) {
			return $default;
		}
		foreach ( $rates as $id => $rate ) {
			if ( self::is_dem( $rate ) ) {
				return $id;
			}
		}
		return $default;
	}

	/** Sous-titre sous la ligne DEM (panier et paiement classiques). */
	public static function subtitle( $method, $index ) {
		if ( ! self::is_dem( $method ) ) {
			return;
		}
		echo '<span class="dem-livraison-subtitle">' . esc_html__( 'Coursier DEM à domicile · suivi en direct', 'dem-livraison' ) . '</span>';
	}

	/** Ligne DEM encadrée, panier classique et panier en blocs. */
	public static function styles() {
		if ( ! ( function_exists( 'is_cart' ) && ( is_cart() || is_checkout() ) ) ) {
			return;
		}
		$css = '
#shipping_method li:has(input[value^="dem_livraison"]),
.wc-block-components-radio-control__option:has(input[value^="dem_livraison"]) {
	border: 2px solid #0086C8 !important;
	border-radius: 10px;
	background: #F0F8FD;
	padding: 12px 14px 12px 44px !important;
	margin: 6px 0;
	position: relative;
}
#shipping_method li:has(input[value^="dem_livraison"]) { padding-left: 14px !important; }
#shipping_method li:has(input[value^="dem_livraison"]) label,
.wc-block-components-radio-control__option:has(input[value^="dem_livraison"]) .wc-block-components-radio-control__label {
	font-weight: 700;
	color: #021520;
}
.dem-livraison-subtitle,
.wc-block-components-radio-control__option:has(input[value^="dem_livraison"]) .wc-block-components-radio-control__label::after {
	display: block;
	font-size: 0.85em;
	font-weight: 600;
	color: #0086C8;
	margin-top: 2px;
}
.wc-block-components-radio-control__option:has(input[value^="dem_livraison"]) .wc-block-components-radio-control__label::after {
	content: "Coursier DEM à domicile · suivi en direct";
}
.wc-block-components-radio-control__option:has(input[value^="dem_livraison"]) .wc-block-components-radio-control__input {
	left: 14px;
}';
		wp_register_style( 'dem-livraison-checkout', false, array(), DEM_LIVRAISON_VERSION );
		wp_enqueue_style( 'dem-livraison-checkout' );
		wp_add_inline_style( 'dem-livraison-checkout', $css );
	}
}
