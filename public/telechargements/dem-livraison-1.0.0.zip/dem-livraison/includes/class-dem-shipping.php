<?php
/**
 * Mode de livraison « Livraison DEM » : prix DEM en direct au panier.
 *
 * Le devis (POST /v1/quotes) est garanti 15 minutes ; son quote_id est gardé
 * sur la ligne de livraison de la commande et réutilisé à la création de la
 * livraison, pour facturer exactement le prix affiché au client.
 */

defined( 'ABSPATH' ) || exit;

class DEM_Livraison_Shipping extends WC_Shipping_Method {

	const CACHE_TTL = 600; // 10 min (le devis vaut 15 min)

	public function __construct( $instance_id = 0 ) {
		$this->id                 = 'dem_livraison';
		$this->instance_id        = absint( $instance_id );
		$this->method_title       = __( 'Livraison DEM', 'dem-livraison' );
		$this->method_description = __( 'Livraison par un coursier DEM à Dakar, au prix calculé par DEM pour l\'adresse du client.', 'dem-livraison' );
		$this->supports           = array( 'shipping-zones', 'instance-settings', 'instance-settings-modal' );
		$this->init();
	}

	public function init() {
		$this->instance_form_fields = array(
			'title'   => array(
				'title'   => __( 'Nom affiché', 'dem-livraison' ),
				'type'    => 'text',
				'default' => __( 'Livraison DEM', 'dem-livraison' ),
			),
			'service' => array(
				'title'   => __( 'Service', 'dem-livraison' ),
				'type'    => 'select',
				'default' => 'standard',
				'options' => array(
					'standard' => __( 'Standard', 'dem-livraison' ),
					'express'  => __( 'Express (coursier le plus proche)', 'dem-livraison' ),
				),
			),
			'extra'   => array(
				'title'       => __( 'Montant ajouté', 'dem-livraison' ),
				'type'        => 'number',
				'default'     => 0,
				'description' => __( 'Ajouté au prix DEM (emballage, marge). 0 : le client paie exactement le prix DEM.', 'dem-livraison' ),
				'custom_attributes' => array( 'min' => 0, 'step' => 50 ),
			),
		);
		$this->title = $this->get_option( 'title', __( 'Livraison DEM', 'dem-livraison' ) );
		add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
	}

	/** Adresse lisible du client, ou '' si trop incomplète pour un devis. */
	public static function destination_address( array $destination ) {
		$country = isset( $destination['country'] ) ? $destination['country'] : '';
		if ( $country && 'SN' !== $country ) {
			return '';
		}
		$line = trim( isset( $destination['address'] ) ? $destination['address'] : ( isset( $destination['address_1'] ) ? $destination['address_1'] : '' ) );
		if ( '' === $line ) {
			return ''; // ville seule (page panier) : pas de devis fiable
		}
		$parts = array_filter( array(
			$line,
			isset( $destination['address_2'] ) ? trim( $destination['address_2'] ) : '',
			isset( $destination['city'] ) ? trim( $destination['city'] ) : '',
			'Sénégal',
		) );
		return implode( ', ', $parts );
	}

	public function calculate_shipping( $package = array() ) {
		$address = self::destination_address( isset( $package['destination'] ) ? $package['destination'] : array() );
		if ( '' === $address ) {
			return;
		}
		$service = $this->get_option( 'service', 'standard' );
		$extra   = max( 0, (float) $this->get_option( 'extra', 0 ) );
		$quote   = self::quote( $address, $service );

		if ( is_wp_error( $quote ) ) {
			$fallback = get_option( 'dem_livraison_fallback_price', '' );
			if ( '' !== $fallback && is_numeric( $fallback ) ) {
				$this->add_rate( array(
					'id'    => $this->get_rate_id(),
					'label' => $this->title,
					'cost'  => (float) $fallback + $extra,
				) );
			}
			return;
		}

		$this->add_rate( array(
			'id'        => $this->get_rate_id(),
			'label'     => $this->title,
			'cost'      => (float) $quote['price'] + $extra,
			'meta_data' => array(
				'_dem_quote_id'      => $quote['quote_id'],
				'_dem_quote_expires' => $quote['expires_at'],
				'_dem_service'       => $service,
			),
		) );
	}

	/**
	 * Devis DEM pour une adresse, en cache 10 min (le panier recalcule souvent).
	 * Renvoie le devis ou un WP_Error.
	 */
	public static function quote( $address, $service = 'standard' ) {
		$pickup = DEM_Livraison_Settings::pickup_store();
		if ( ! $pickup ) {
			return new WP_Error( 'NO_PICKUP', __( 'Point de retrait DEM non configuré.', 'dem-livraison' ) );
		}
		$cache_key = 'dem_q_' . md5( $address . '|' . $service . '|' . $pickup['id'] . '|' . DEM_Livraison_API::key() );
		$cached    = get_transient( $cache_key );
		if ( is_array( $cached ) && strtotime( $cached['expires_at'] ) > time() + 120 ) {
			return $cached;
		}

		$quote = DEM_Livraison_API::request( 'POST', '/quotes', array(
			'pickup'  => array(
				'address'   => $pickup['address'],
				'latitude'  => (float) $pickup['latitude'],
				'longitude' => (float) $pickup['longitude'],
			),
			'dropoff' => array( 'address' => $address ),
			'service' => $service,
		) );
		if ( ! is_wp_error( $quote ) ) {
			set_transient( $cache_key, $quote, self::CACHE_TTL );
			// Pour retirer ce devis du cache dès qu'une commande l'utilise
			set_transient( 'dem_qk_' . $quote['quote_id'], $cache_key, self::CACHE_TTL );
		}
		return $quote;
	}

	/**
	 * Un devis ne sert qu'une fois : après usage (ou s'il est refusé), il
	 * quitte le cache, le client suivant reçoit un devis neuf au même prix
	 * garanti au lieu d'un devis déjà consommé.
	 */
	public static function forget_quote( $quote_id ) {
		if ( ! $quote_id ) {
			return;
		}
		$cache_key = get_transient( 'dem_qk_' . $quote_id );
		if ( $cache_key ) {
			delete_transient( $cache_key );
		}
		delete_transient( 'dem_qk_' . $quote_id );
	}
}
