<?php
/**
 * Client de l'API DEM (https://api.dem.sn/v1).
 * Documentation : https://www.dem.sn/developpeurs
 *
 * La clé n'est jamais écrite dans les journaux.
 */

defined( 'ABSPATH' ) || exit;

class DEM_Livraison_API {

	const DEFAULT_BASE = 'https://api.dem.sn/v1';

	/** Adresse de l'API (modifiable pour les tests : constante DEM_API_BASE ou filtre). */
	public static function base() {
		$base = defined( 'DEM_API_BASE' ) ? DEM_API_BASE : self::DEFAULT_BASE;
		return rtrim( apply_filters( 'dem_livraison_api_base', $base ), '/' );
	}

	public static function key() {
		return trim( (string) get_option( 'dem_livraison_api_key', '' ) );
	}

	public static function is_test() {
		return 0 === strpos( self::key(), 'dem_test_' );
	}

	/**
	 * Appel de l'API. Renvoie le tableau décodé, ou un WP_Error dont le code
	 * est le code d'erreur DEM (ex. INVALID_ADDRESS) et les données contiennent
	 * status, request_id, details.
	 */
	public static function request( $method, $path, $body = null, $idempotency_key = null ) {
		$key = self::key();
		if ( '' === $key ) {
			return new WP_Error( 'NO_API_KEY', __( 'Clé API DEM manquante (WooCommerce › Réglages › DEM Livraison).', 'dem-livraison' ) );
		}

		$args = array(
			'method'  => $method,
			'timeout' => 15,
			'headers' => array(
				'Authorization' => 'Bearer ' . $key,
				'Accept'        => 'application/json',
				'User-Agent'    => 'DEM-Livraison-WooCommerce/' . DEM_LIVRAISON_VERSION . '; ' . home_url(),
			),
		);
		if ( null !== $body ) {
			$args['headers']['Content-Type'] = 'application/json';
			$args['body']                    = wp_json_encode( $body );
		}
		if ( $idempotency_key ) {
			$args['headers']['Idempotency-Key'] = $idempotency_key;
		}

		$response = wp_remote_request( self::base() . $path, $args );
		if ( is_wp_error( $response ) ) {
			self::log( sprintf( '%s %s : réseau — %s', $method, $path, $response->get_error_message() ), 'warning' );
			return new WP_Error( 'NETWORK', $response->get_error_message(), array( 'status' => 0, 'retryable' => true ) );
		}

		$status     = (int) wp_remote_retrieve_response_code( $response );
		$data       = json_decode( wp_remote_retrieve_body( $response ), true );
		$request_id = wp_remote_retrieve_header( $response, 'x-request-id' );

		if ( $status >= 200 && $status < 300 ) {
			self::log( sprintf( '%s %s : %d (%s)', $method, $path, $status, $request_id ), 'debug' );
			return is_array( $data ) ? $data : array();
		}

		$error   = ( is_array( $data ) && isset( $data['error'] ) ) ? $data['error'] : array();
		$code    = isset( $error['code'] ) ? $error['code'] : 'HTTP_' . $status;
		$message = isset( $error['message'] ) ? $error['message'] : sprintf( __( 'Erreur DEM (HTTP %d).', 'dem-livraison' ), $status );
		self::log( sprintf( '%s %s : %d %s — %s (%s)', $method, $path, $status, $code, $message, $request_id ), 'warning' );

		return new WP_Error( $code, $message, array(
			'status'     => $status,
			'request_id' => $request_id ? $request_id : ( isset( $error['request_id'] ) ? $error['request_id'] : null ),
			'details'    => isset( $error['details'] ) ? $error['details'] : null,
			// Réessayer plus tard a un sens : réseau, serveur, limite, requête en cours
			'retryable'  => $status >= 500 || 429 === $status || 'IDEMPOTENCY_IN_PROGRESS' === $code,
		) );
	}

	/** Message d'erreur lisible pour une note de commande ou l'admin. */
	public static function describe( WP_Error $error ) {
		$data = $error->get_error_data();
		$rid  = is_array( $data ) && ! empty( $data['request_id'] ) ? ' [' . $data['request_id'] . ']' : '';
		return $error->get_error_message() . ' (' . $error->get_error_code() . ')' . $rid;
	}

	public static function is_retryable( WP_Error $error ) {
		$data = $error->get_error_data();
		return is_array( $data ) && ! empty( $data['retryable'] );
	}

	/** Journal WooCommerce (WooCommerce › État › Journaux, source « dem-livraison »). */
	public static function log( $message, $level = 'info' ) {
		if ( 'debug' === $level && 'yes' !== get_option( 'dem_livraison_debug', 'no' ) ) {
			return;
		}
		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->log( $level, $message, array( 'source' => 'dem-livraison' ) );
		}
	}
}
