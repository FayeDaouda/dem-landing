<?php
/**
 * Commandes WooCommerce ⇄ livraisons DEM.
 *
 * - création automatique au paiement (statut « En cours ») pour les commandes
 *   livrées par « Livraison DEM », ou à la main (bouton dans la commande) ;
 * - Idempotency-Key liée à la commande : jamais deux livraisons pour une
 *   commande, même si l'envoi est répété ;
 * - DEM injoignable : nouvel essai automatique (Action Scheduler), 5 fois max ;
 * - panneau « Livraison DEM » dans la commande, lien de suivi pour le client.
 */

defined( 'ABSPATH' ) || exit;

class DEM_Livraison_Orders {

	const MAX_ATTEMPTS = 5;
	const FINAL_STATUSES = array( 'DELIVERED', 'CANCELLED' );

	public static function init() {
		add_action( 'woocommerce_order_status_processing', array( __CLASS__, 'on_paid' ), 20, 1 );
		add_action( 'dem_livraison_retry_create', array( __CLASS__, 'retry_create' ), 10, 1 );
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_box' ) );
		add_action( 'admin_post_dem_livraison_order_action', array( __CLASS__, 'handle_action' ) );
		add_action( 'woocommerce_email_after_order_table', array( __CLASS__, 'email_tracking' ), 10, 4 );
		add_action( 'woocommerce_order_details_after_order_table', array( __CLASS__, 'customer_tracking' ) );
	}

	// ── Création ─────────────────────────────────────────────────────────────

	public static function uses_dem( WC_Order $order ) {
		foreach ( $order->get_shipping_methods() as $item ) {
			if ( 'dem_livraison' === $item->get_method_id() ) {
				return true;
			}
		}
		return false;
	}

	public static function on_paid( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order || 'yes' !== get_option( 'dem_livraison_auto_create', 'yes' ) || ! self::uses_dem( $order ) ) {
			return;
		}
		self::create( $order );
	}

	public static function retry_create( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( $order ) {
			self::create( $order, true );
		}
	}

	/**
	 * Clé d'idempotence : une par commande et par boutique (et par renvoi
	 * après annulation, sinon DEM rejouerait la livraison annulée).
	 */
	public static function idempotency_key( WC_Order $order ) {
		$resend = (int) $order->get_meta( '_dem_resend' );
		return 'wc-' . substr( md5( home_url() ), 0, 10 ) . '-' . $order->get_id() . ( $resend ? '-n' . $resend : '' );
	}

	/** Mobile sénégalais → +221XXXXXXXXX, ou '' si le numéro n'en est pas un. */
	public static function senegal_phone( $raw ) {
		$digits = preg_replace( '/\D+/', '', (string) $raw );
		if ( 0 === strpos( $digits, '00221' ) ) {
			$digits = substr( $digits, 5 );
		} elseif ( 0 === strpos( $digits, '221' ) && strlen( $digits ) > 9 ) {
			$digits = substr( $digits, 3 );
		}
		return preg_match( '/^(70|71|75|76|77|78)\d{7}$/', $digits ) ? '+221' . $digits : '';
	}

	/** Devis encore valable sur la ligne de livraison (prix garanti au client). */
	private static function order_quote( WC_Order $order ) {
		foreach ( $order->get_shipping_methods() as $item ) {
			if ( 'dem_livraison' !== $item->get_method_id() ) {
				continue;
			}
			$quote_id = $item->get_meta( '_dem_quote_id' );
			$expires  = strtotime( (string) $item->get_meta( '_dem_quote_expires' ) );
			if ( $quote_id && $expires && $expires > time() + 30 ) {
				return array( $quote_id, $item->get_meta( '_dem_service' ) );
			}
			return array( null, $item->get_meta( '_dem_service' ) );
		}
		return array( null, null );
	}

	public static function build_payload( WC_Order $order, $use_quote = true ) {
		list( $quote_id, $service ) = $use_quote ? self::order_quote( $order ) : array( null, null );

		$has_shipping = (bool) $order->get_shipping_address_1();
		$name         = trim( $has_shipping
			? $order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name()
			: $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
		$phone        = method_exists( $order, 'get_shipping_phone' ) ? $order->get_shipping_phone() : '';
		$phone        = self::senegal_phone( $phone ? $phone : $order->get_billing_phone() );

		$address = DEM_Livraison_Shipping_Address::from_order( $order );
		$count   = 0;
		foreach ( $order->get_items() as $item ) {
			$count += (int) $item->get_quantity();
		}

		$payload = array(
			'external_order_id' => (string) $order->get_order_number(),
			'customer'          => array_filter( array( 'name' => mb_substr( $name, 0, 100 ), 'phone' => $phone ) ),
			'dropoff'           => array( 'address' => mb_substr( $address, 0, 300 ) ),
			'package'           => array(
				/* translators: %s: numéro de commande */
				'description' => sprintf( __( 'Commande %s', 'dem-livraison' ), $order->get_order_number() ),
				'quantity'    => max( 1, min( 999, $count ) ),
			),
			'payment'           => 'wallet' === get_option( 'dem_livraison_payment', 'cash' )
				? array( 'method' => 'WALLET' )
				: array( 'method' => 'CASH', 'paid_by' => 'sender' ),
			'metadata'          => array(
				'source'      => 'woocommerce',
				'wc_order_id' => (string) $order->get_id(),
				'site'        => (string) wp_parse_url( home_url(), PHP_URL_HOST ),
			),
		);
		if ( $order->get_customer_id() ) {
			$payload['external_customer_id'] = (string) $order->get_customer_id();
		}
		$store_id = get_option( 'dem_livraison_store_id', '' );
		$payload['pickup'] = array_filter( array(
			'store_id' => $store_id ? $store_id : null,
			'name'     => mb_substr( get_bloginfo( 'name' ), 0, 100 ),
		) );
		if ( $quote_id ) {
			$payload['quote_id'] = $quote_id;
		} elseif ( $service ) {
			$payload['service'] = $service;
		}
		return $payload;
	}

	/**
	 * Crée la livraison DEM de la commande. Renvoie true si elle existe
	 * (créée maintenant ou déjà), sinon false (raison dans les notes).
	 */
	public static function create( WC_Order $order, $is_retry = false ) {
		if ( $order->get_meta( '_dem_delivery_id' ) ) {
			return true;
		}
		$payload = self::build_payload( $order );
		if ( empty( $payload['customer']['phone'] ) ) {
			$order->add_order_note( __( 'Livraison DEM non créée : le téléphone du client n\'est pas un mobile sénégalais (70, 71, 75, 76, 77, 78). Corrigez-le puis cliquez « Envoyer à DEM ».', 'dem-livraison' ) );
			return false;
		}
		if ( '' === trim( $payload['dropoff']['address'], ', ' ) ) {
			$order->add_order_note( __( 'Livraison DEM non créée : adresse de livraison vide.', 'dem-livraison' ) );
			return false;
		}

		$res = DEM_Livraison_API::request( 'POST', '/deliveries', $payload, self::idempotency_key( $order ) );
		if ( ! empty( $payload['quote_id'] ) && class_exists( 'DEM_Livraison_Shipping' ) ) {
			DEM_Livraison_Shipping::forget_quote( $payload['quote_id'] );
		}

		// Devis expiré, déjà utilisé ou différent : on recrée sans devis (prix recalculé)
		if ( is_wp_error( $res ) && in_array( $res->get_error_code(), array( 'QUOTE_EXPIRED', 'QUOTE_ALREADY_USED', 'QUOTE_MISMATCH', 'QUOTE_NOT_FOUND' ), true ) ) {
			$payload = self::build_payload( $order, false );
			$res     = DEM_Livraison_API::request( 'POST', '/deliveries', $payload, self::idempotency_key( $order ) . '-r' );
		}

		if ( is_wp_error( $res ) ) {
			$attempts = (int) $order->get_meta( '_dem_attempts' ) + 1;
			$order->update_meta_data( '_dem_attempts', $attempts );
			$order->save();
			if ( DEM_Livraison_API::is_retryable( $res ) && $attempts < self::MAX_ATTEMPTS && function_exists( 'as_schedule_single_action' ) ) {
				as_schedule_single_action( time() + 60 * $attempts * $attempts, 'dem_livraison_retry_create', array( $order->get_id() ), 'dem-livraison' );
				/* translators: %s: erreur */
				$order->add_order_note( sprintf( __( 'DEM injoignable pour l\'instant, nouvel essai automatique dans quelques minutes. %s', 'dem-livraison' ), DEM_Livraison_API::describe( $res ) ) );
			} else {
				/* translators: %s: erreur */
				$order->add_order_note( sprintf( __( 'Livraison DEM non créée : %s', 'dem-livraison' ), DEM_Livraison_API::describe( $res ) ) );
			}
			return false;
		}

		self::store_delivery( $order, $res );
		$order->add_order_note( sprintf(
			/* translators: 1: identifiant DEM, 2: prix, 3: lien de suivi */
			__( 'Livraison DEM créée (%1$s, %2$s F). Suivi : %3$s', 'dem-livraison' ),
			$res['id'],
			number_format_i18n( $res['price']['amount'] ),
			$res['tracking_url'] ? $res['tracking_url'] : __( 'mode test', 'dem-livraison' )
		) );
		return true;
	}

	/** Enregistre l'état DEM de la livraison sur la commande. */
	public static function store_delivery( WC_Order $order, array $delivery ) {
		$order->update_meta_data( '_dem_delivery_id', $delivery['id'] );
		$order->update_meta_data( '_dem_status', $delivery['status'] );
		$order->update_meta_data( '_dem_livemode', ! empty( $delivery['livemode'] ) ? 'yes' : 'no' );
		$order->update_meta_data( '_dem_tracking_url', isset( $delivery['tracking_url'] ) ? (string) $delivery['tracking_url'] : '' );
		$order->update_meta_data( '_dem_price', isset( $delivery['price']['amount'] ) ? $delivery['price']['amount'] : '' );
		$order->update_meta_data( '_dem_driver', ! empty( $delivery['driver'] ) ? wp_json_encode( $delivery['driver'] ) : '' );
		$order->update_meta_data( '_dem_updated_at', time() );
		$order->delete_meta_data( '_dem_attempts' );
		$order->save();
	}

	public static function status_label( $status ) {
		$labels = array(
			'PENDING'          => __( 'Créée', 'dem-livraison' ),
			'SEARCHING_DRIVER' => __( 'Recherche d\'un coursier', 'dem-livraison' ),
			'DRIVER_ASSIGNED'  => __( 'Coursier en route vers la boutique', 'dem-livraison' ),
			'PICKED_UP'        => __( 'Colis récupéré, en route vers le client', 'dem-livraison' ),
			'IN_TRANSIT'       => __( 'En route', 'dem-livraison' ),
			'DELIVERED'        => __( 'Livrée', 'dem-livraison' ),
			'CANCELLED'        => __( 'Annulée', 'dem-livraison' ),
			'SCHEDULED'        => __( 'Programmée', 'dem-livraison' ),
		);
		return isset( $labels[ $status ] ) ? $labels[ $status ] : $status;
	}

	// ── Panneau dans la commande ─────────────────────────────────────────────

	public static function add_meta_box() {
		$screen = function_exists( 'wc_get_page_screen_id' ) ? wc_get_page_screen_id( 'shop-order' ) : 'shop_order';
		add_meta_box( 'dem-livraison', __( 'Livraison DEM', 'dem-livraison' ), array( __CLASS__, 'render_meta_box' ), $screen, 'side', 'high' );
	}

	private static function action_url( WC_Order $order, $do ) {
		return wp_nonce_url(
			admin_url( 'admin-post.php?action=dem_livraison_order_action&do=' . $do . '&order_id=' . $order->get_id() ),
			'dem_livraison_order_' . $order->get_id()
		);
	}

	public static function render_meta_box( $post_or_order ) {
		$order = $post_or_order instanceof WC_Order ? $post_or_order : wc_get_order( $post_or_order->ID );
		if ( ! $order ) {
			return;
		}
		$id = $order->get_meta( '_dem_delivery_id' );

		if ( ! $id ) {
			echo '<p>' . esc_html__( 'Pas encore de livraison DEM pour cette commande.', 'dem-livraison' ) . '</p>';
			printf( '<p><a class="button button-primary" href="%s">%s</a></p>', esc_url( self::action_url( $order, 'create' ) ), esc_html__( 'Envoyer à DEM', 'dem-livraison' ) );
			if ( DEM_Livraison_API::is_test() ) {
				echo '<p class="description">' . esc_html__( 'Mode test : aucune vraie course.', 'dem-livraison' ) . '</p>';
			}
			return;
		}

		$status   = $order->get_meta( '_dem_status' );
		$tracking = $order->get_meta( '_dem_tracking_url' );
		$driver   = json_decode( (string) $order->get_meta( '_dem_driver' ), true );

		echo '<p><strong>' . esc_html( self::status_label( $status ) ) . '</strong>';
		if ( 'no' === $order->get_meta( '_dem_livemode' ) ) {
			echo ' <mark style="background:#efe6ff;padding:1px 6px">' . esc_html__( 'test', 'dem-livraison' ) . '</mark>';
		}
		echo '<br><code>' . esc_html( $id ) . '</code></p>';
		if ( $order->get_meta( '_dem_price' ) ) {
			/* translators: %s: prix */
			echo '<p>' . esc_html( sprintf( __( 'Prix DEM : %s F', 'dem-livraison' ), number_format_i18n( $order->get_meta( '_dem_price' ) ) ) ) . '</p>';
		}
		if ( is_array( $driver ) && ! empty( $driver['first_name'] ) ) {
			echo '<p>' . esc_html__( 'Coursier : ', 'dem-livraison' ) . esc_html( $driver['first_name'] );
			if ( ! empty( $driver['phone'] ) ) {
				echo ' — <a href="tel:' . esc_attr( $driver['phone'] ) . '">' . esc_html( $driver['phone'] ) . '</a>';
			}
			echo '</p>';
		}
		if ( $tracking ) {
			echo '<p><a href="' . esc_url( $tracking ) . '" target="_blank" rel="noopener">' . esc_html__( 'Suivi en direct ↗', 'dem-livraison' ) . '</a></p>';
		}
		echo '<p>';
		printf( '<a class="button" href="%s">%s</a> ', esc_url( self::action_url( $order, 'refresh' ) ), esc_html__( 'Actualiser', 'dem-livraison' ) );
		if ( ! in_array( $status, self::FINAL_STATUSES, true ) && 'PICKED_UP' !== $status ) {
			printf(
				'<a class="button" style="color:#b32d2e" href="%s" onclick="return confirm(%s)">%s</a>',
				esc_url( self::action_url( $order, 'cancel' ) ),
				esc_attr( wp_json_encode( __( 'Annuler la livraison DEM ?', 'dem-livraison' ) ) ),
				esc_html__( 'Annuler', 'dem-livraison' )
			);
		}
		echo '</p>';
		if ( 'CANCELLED' === $status ) {
			printf( '<p><a class="button button-primary" href="%s">%s</a></p>', esc_url( self::action_url( $order, 'recreate' ) ), esc_html__( 'Renvoyer à DEM', 'dem-livraison' ) );
		}
	}

	public static function handle_action() {
		$order_id = isset( $_GET['order_id'] ) ? absint( $_GET['order_id'] ) : 0;
		$do       = isset( $_GET['do'] ) ? sanitize_key( $_GET['do'] ) : '';
		if ( ! current_user_can( 'edit_shop_orders' ) || ! check_admin_referer( 'dem_livraison_order_' . $order_id ) ) {
			wp_die( esc_html__( 'Action non autorisée.', 'dem-livraison' ) );
		}
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			wp_die( esc_html__( 'Commande introuvable.', 'dem-livraison' ) );
		}
		$id = $order->get_meta( '_dem_delivery_id' );

		if ( 'create' === $do ) {
			self::create( $order );
		} elseif ( 'recreate' === $do ) {
			// Livraison annulée : nouvelle livraison, nouvelle clé d'idempotence
			$order->delete_meta_data( '_dem_delivery_id' );
			$order->update_meta_data( '_dem_resend', (int) $order->get_meta( '_dem_resend' ) + 1 );
			$order->save();
			self::create( $order );
		} elseif ( 'refresh' === $do && $id ) {
			$res = DEM_Livraison_API::request( 'GET', '/deliveries/' . rawurlencode( $id ) );
			if ( is_wp_error( $res ) ) {
				$order->add_order_note( __( 'Actualisation DEM impossible : ', 'dem-livraison' ) . DEM_Livraison_API::describe( $res ) );
			} else {
				self::store_delivery( $order, $res );
			}
		} elseif ( 'cancel' === $do && $id ) {
			$res = DEM_Livraison_API::request( 'POST', '/deliveries/' . rawurlencode( $id ) . '/cancel', array( 'reason' => 'CUSTOMER_CANCELLED' ) );
			if ( is_wp_error( $res ) ) {
				$order->add_order_note( __( 'Annulation DEM refusée : ', 'dem-livraison' ) . DEM_Livraison_API::describe( $res ) );
			} else {
				self::store_delivery( $order, $res );
				$order->add_order_note( __( 'Livraison DEM annulée depuis la boutique.', 'dem-livraison' ) );
			}
		}

		wp_safe_redirect( wp_get_referer() ? wp_get_referer() : $order->get_edit_order_url() );
		exit;
	}

	// ── Lien de suivi pour le client ─────────────────────────────────────────

	private static function tracking_for_customer( $order ) {
		if ( ! $order instanceof WC_Order ) {
			return '';
		}
		$url    = $order->get_meta( '_dem_tracking_url' );
		$status = $order->get_meta( '_dem_status' );
		return ( $url && ! in_array( $status, self::FINAL_STATUSES, true ) ) ? $url : '';
	}

	public static function email_tracking( $order, $sent_to_admin, $plain_text, $email = null ) {
		$url = self::tracking_for_customer( $order );
		if ( ! $url || $sent_to_admin ) {
			return;
		}
		if ( $plain_text ) {
			echo "\n" . esc_html__( 'Suivez votre livraison DEM en direct :', 'dem-livraison' ) . ' ' . esc_url_raw( $url ) . "\n";
		} else {
			echo '<p style="margin:16px 0"><strong>' . esc_html__( 'Suivez votre livraison en direct', 'dem-livraison' ) . '</strong><br><a href="' . esc_url( $url ) . '">' . esc_html( $url ) . '</a></p>';
		}
	}

	public static function customer_tracking( $order ) {
		$url = self::tracking_for_customer( $order );
		if ( $url ) {
			echo '<p class="dem-livraison-suivi"><a class="button" href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html__( 'Suivre ma livraison', 'dem-livraison' ) . '</a></p>';
		}
	}
}

/** Adresse de livraison d'une commande, au format attendu par DEM. */
class DEM_Livraison_Shipping_Address {
	public static function from_order( WC_Order $order ) {
		$use_shipping = (bool) $order->get_shipping_address_1();
		$parts        = $use_shipping
			? array( $order->get_shipping_address_1(), $order->get_shipping_address_2(), $order->get_shipping_city() )
			: array( $order->get_billing_address_1(), $order->get_billing_address_2(), $order->get_billing_city() );
		$parts        = array_filter( array_map( 'trim', $parts ) );
		$parts[]      = 'Sénégal';
		return implode( ', ', $parts );
	}
}
