<?php
/**
 * Informations dont le coursier a besoin, vérifiées AVANT le paiement :
 * - téléphone rendu obligatoire au paiement (réglage, oui par défaut) ;
 * - « Livraison DEM » choisie ⇒ un mobile sénégalais valide est exigé, sinon
 *   la commande n'est pas passée et le client voit pourquoi (paiement
 *   classique et en blocs) ;
 * - au Sénégal, le complément d'adresse devient « Repère » (les rues ont
 *   rarement un numéro : le coursier s'oriente avec un repère).
 */

defined( 'ABSPATH' ) || exit;

class DEM_Livraison_Fields {

	public static function init() {
		if ( 'yes' === get_option( 'dem_livraison_require_phone', 'yes' ) ) {
			// Sans changer le réglage de la boutique : relu à chaque page
			add_filter( 'option_woocommerce_checkout_phone_field', array( __CLASS__, 'phone_required' ) );
			add_filter( 'default_option_woocommerce_checkout_phone_field', array( __CLASS__, 'phone_required' ) );
		}
		add_filter( 'woocommerce_get_country_locale', array( __CLASS__, 'senegal_landmark' ) );
		add_action( 'woocommerce_after_checkout_validation', array( __CLASS__, 'validate_classic' ), 10, 2 );
		add_action( 'woocommerce_store_api_checkout_update_order_from_request', array( __CLASS__, 'validate_blocks' ), 10, 2 );
	}

	public static function phone_required() {
		return 'required';
	}

	public static function senegal_landmark( $locale ) {
		$locale['SN']['address_2'] = array_merge(
			isset( $locale['SN']['address_2'] ) ? (array) $locale['SN']['address_2'] : array(),
			array(
				'label'       => __( 'Repère', 'dem-livraison' ),
				'placeholder' => __( 'Ex. face pharmacie Keur Gorgui, 2e étage', 'dem-livraison' ),
				'required'    => false,
				'hidden'      => false,
			)
		);
		return $locale;
	}

	public static function phone_message() {
		return __( 'Livraison DEM : indiquez un numéro de mobile sénégalais (ex. 77 123 45 67). Le coursier vous appelle à l\'arrivée.', 'dem-livraison' );
	}

	/** Le mode choisi pour l'un des colis est-il la livraison DEM ? */
	private static function chose_dem( $methods ) {
		foreach ( (array) $methods as $method ) {
			if ( is_string( $method ) && 0 === strpos( $method, 'dem_livraison' ) ) {
				return true;
			}
		}
		return false;
	}

	/** Paiement classique */
	public static function validate_classic( $data, $errors ) {
		if ( ! self::chose_dem( isset( $data['shipping_method'] ) ? $data['shipping_method'] : array() ) ) {
			return;
		}
		$phone = ! empty( $data['shipping_phone'] ) ? $data['shipping_phone'] : ( isset( $data['billing_phone'] ) ? $data['billing_phone'] : '' );
		if ( '' === DEM_Livraison_Orders::senegal_phone( $phone ) ) {
			$errors->add( 'dem_livraison_phone', self::phone_message(), array( 'id' => 'billing_phone' ) );
		}
	}

	/** Paiement en blocs (Store API) : une exception bloque la commande et affiche le message */
	public static function validate_blocks( $order, $request ) {
		$methods = array();
		foreach ( $order->get_shipping_methods() as $item ) {
			$methods[] = $item->get_method_id();
		}
		if ( ! self::chose_dem( $methods ) ) {
			return;
		}
		$phone = method_exists( $order, 'get_shipping_phone' ) && $order->get_shipping_phone() ? $order->get_shipping_phone() : $order->get_billing_phone();
		if ( '' === DEM_Livraison_Orders::senegal_phone( $phone ) ) {
			throw new \Automattic\WooCommerce\StoreApi\Exceptions\RouteException( 'dem_livraison_phone', self::phone_message(), 400 );
		}
	}
}
