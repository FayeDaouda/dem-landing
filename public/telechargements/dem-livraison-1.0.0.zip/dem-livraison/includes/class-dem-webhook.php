<?php
/**
 * Réception des webhooks DEM : POST /wp-json/dem/v1/webhook
 *
 * Signature : X-DEM-Signature = "v1=" + HMAC-SHA256(secret, X-DEM-Timestamp + "." + corps brut)
 * Refus au-delà de 5 minutes (rejeu). Un même événement n'est traité qu'une fois.
 */

defined( 'ABSPATH' ) || exit;

class DEM_Livraison_Webhook {

	const TOLERANCE = 300;

	public static function init() {
		add_action( 'rest_api_init', function () {
			register_rest_route( 'dem/v1', '/webhook', array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'handle' ),
				'permission_callback' => '__return_true', // authentifié par la signature
			) );
		} );
	}

	/** Signature valide et récente ? */
	public static function verify( $body, $timestamp, $signature, $secret, $now = null ) {
		if ( ! $secret || ! $timestamp || ! $signature || ! ctype_digit( (string) $timestamp ) ) {
			return false;
		}
		$now = null === $now ? time() : $now;
		if ( abs( $now - (int) $timestamp ) > self::TOLERANCE ) {
			return false;
		}
		$expected = 'v1=' . hash_hmac( 'sha256', $timestamp . '.' . $body, $secret );
		return hash_equals( $expected, (string) $signature );
	}

	public static function handle( WP_REST_Request $request ) {
		$body   = $request->get_body();
		$secret = get_option( 'dem_livraison_webhook_secret', '' );
		if ( ! self::verify( $body, $request->get_header( 'x-dem-timestamp' ), $request->get_header( 'x-dem-signature' ), $secret ) ) {
			DEM_Livraison_API::log( 'Webhook refusé : signature absente, invalide ou trop ancienne.', 'warning' );
			return new WP_REST_Response( array( 'error' => 'invalid_signature' ), 400 );
		}

		$event = json_decode( $body, true );
		if ( ! is_array( $event ) || empty( $event['id'] ) || empty( $event['type'] ) ) {
			return new WP_REST_Response( array( 'error' => 'invalid_payload' ), 400 );
		}

		// Un événement peut être renvoyé (relance, rejeu) : traité une seule fois
		$seen_key = 'dem_evt_' . md5( $event['id'] );
		if ( get_transient( $seen_key ) ) {
			return new WP_REST_Response( array( 'received' => true, 'duplicate' => true ), 200 );
		}
		set_transient( $seen_key, 1, 3 * DAY_IN_SECONDS );

		if ( 0 === strpos( $event['type'], 'delivery.' ) && isset( $event['data']['object'] ) ) {
			self::apply( $event );
		}
		return new WP_REST_Response( array( 'received' => true ), 200 );
	}

	/** Met la commande à jour d'après la livraison reçue. */
	public static function apply( array $event ) {
		$delivery = $event['data']['object'];
		$order_id = isset( $delivery['metadata']['wc_order_id'] ) ? absint( $delivery['metadata']['wc_order_id'] ) : 0;
		$order    = $order_id ? wc_get_order( $order_id ) : null;
		// Garde-fou : la livraison doit être celle enregistrée sur la commande
		if ( ! $order || $order->get_meta( '_dem_delivery_id' ) !== $delivery['id'] ) {
			DEM_Livraison_API::log( sprintf( 'Webhook %s ignoré : livraison %s inconnue de la boutique.', $event['type'], $delivery['id'] ), 'info' );
			return;
		}

		// Arrivés dans le désordre : on n'écrase pas un état plus récent
		$event_at = strtotime( isset( $event['created_at'] ) ? $event['created_at'] : 'now' );
		$last_at  = (int) $order->get_meta( '_dem_event_at' );
		if ( $event_at && $last_at && $event_at < $last_at ) {
			return;
		}

		DEM_Livraison_Orders::store_delivery( $order, $delivery );
		$order->update_meta_data( '_dem_event_at', $event_at );
		$order->save();

		$driver = isset( $delivery['driver'] ) && is_array( $delivery['driver'] ) ? $delivery['driver'] : array();
		switch ( $event['type'] ) {
			case 'delivery.driver_assigned':
				$order->add_order_note( sprintf(
					/* translators: 1: prénom, 2: téléphone */
					__( 'DEM : coursier trouvé — %1$s %2$s, en route vers la boutique.', 'dem-livraison' ),
					isset( $driver['first_name'] ) ? $driver['first_name'] : '',
					isset( $driver['phone'] ) ? '(' . $driver['phone'] . ')' : ''
				) );
				break;
			case 'delivery.driver_unassigned':
				$order->add_order_note( __( 'DEM : le coursier s\'est désisté, recherche d\'un autre coursier.', 'dem-livraison' ) );
				break;
			case 'delivery.picked_up':
				$order->add_order_note( __( 'DEM : colis récupéré, en route vers le client.', 'dem-livraison' ) );
				break;
			case 'delivery.delivered':
				$order->add_order_note( __( 'DEM : commande livrée.', 'dem-livraison' ) );
				if ( 'yes' === get_option( 'dem_livraison_complete_on_delivered', 'yes' ) && ! $order->has_status( 'completed' ) ) {
					$order->update_status( 'completed', __( 'Livrée par DEM.', 'dem-livraison' ) );
				}
				break;
			case 'delivery.cancelled':
				$reason = isset( $delivery['cancellation']['reason'] ) ? $delivery['cancellation']['reason'] : '';
				$order->add_order_note( 'NO_DRIVER_FOUND' === $reason
					? __( 'DEM : aucun coursier trouvé, livraison annulée. Utilisez « Renvoyer à DEM » dans la commande.', 'dem-livraison' )
					/* translators: %s: motif */
					: sprintf( __( 'DEM : livraison annulée (%s).', 'dem-livraison' ), $reason ? $reason : '—' ) );
				break;
		}
	}
}
