<?php
/**
 * Onglet WooCommerce › Réglages › DEM Livraison.
 */

defined( 'ABSPATH' ) || exit;

class DEM_Livraison_Settings {

	const TAB = 'dem_livraison';

	/** Droits dont le module a besoin sur la clé. */
	const NEEDED_SCOPES = array( 'quotes:read', 'deliveries:create', 'deliveries:read', 'deliveries:cancel', 'tracking:read', 'webhooks:manage' );

	const WEBHOOK_EVENTS = array(
		'delivery.created', 'delivery.driver_assigned', 'delivery.driver_unassigned',
		'delivery.picked_up', 'delivery.delivered', 'delivery.cancelled',
	);

	public static function init() {
		add_filter( 'woocommerce_settings_tabs_array', array( __CLASS__, 'add_tab' ), 50 );
		add_action( 'woocommerce_settings_tabs_' . self::TAB, array( __CLASS__, 'render' ) );
		add_action( 'woocommerce_update_options_' . self::TAB, array( __CLASS__, 'save' ) );
		add_action( 'admin_post_dem_livraison_connect_webhook', array( __CLASS__, 'connect_webhook' ) );
	}

	public static function add_tab( $tabs ) {
		$tabs[ self::TAB ] = __( 'DEM Livraison', 'dem-livraison' );
		return $tabs;
	}

	public static function fields() {
		$stores = array( '' => __( 'Point de retrait par défaut du compte DEM', 'dem-livraison' ) );
		foreach ( self::stores() as $store ) {
			$stores[ $store['id'] ] = $store['name'] . ' — ' . $store['address'];
		}

		return array(
			array(
				'title' => __( 'Connexion à DEM', 'dem-livraison' ),
				'type'  => 'title',
				'desc'  => __( 'Créez une clé dans l\'application DEM Pro (Compte › API DEM) ou demandez-la à DEM. Commencez par une clé de Test : aucune vraie course n\'est créée.', 'dem-livraison' ),
				'id'    => 'dem_livraison_connexion',
			),
			array(
				'title'    => __( 'Clé API', 'dem-livraison' ),
				'id'       => 'dem_livraison_api_key',
				'type'     => 'password',
				'desc_tip' => __( 'Commence par dem_test_ (essais) ou dem_live_ (vraies livraisons).', 'dem-livraison' ),
				'css'      => 'min-width:420px;',
			),
			array( 'type' => 'sectionend', 'id' => 'dem_livraison_connexion' ),

			array(
				'title' => __( 'Livraisons', 'dem-livraison' ),
				'type'  => 'title',
				'id'    => 'dem_livraison_livraisons',
			),
			array(
				'title'   => __( 'Point de retrait', 'dem-livraison' ),
				'id'      => 'dem_livraison_store_id',
				'type'    => 'select',
				'options' => $stores,
				'desc'    => __( 'Adresses enregistrées dans votre compte DEM Pro.', 'dem-livraison' ),
			),
			array(
				'title'   => __( 'Création automatique', 'dem-livraison' ),
				'id'      => 'dem_livraison_auto_create',
				'type'    => 'checkbox',
				'default' => 'yes',
				'desc'    => __( 'Créer la livraison DEM dès que la commande est payée (statut « En cours »). Sinon, bouton « Envoyer à DEM » dans la commande.', 'dem-livraison' ),
			),
			array(
				'title'   => __( 'Paiement du coursier', 'dem-livraison' ),
				'id'      => 'dem_livraison_payment',
				'type'    => 'select',
				'default' => 'cash',
				'options' => array(
					'cash'   => __( 'Je paie le coursier en espèces', 'dem-livraison' ),
					'wallet' => __( 'Débité de mon wallet DEM Pro', 'dem-livraison' ),
				),
				'desc'    => __( 'Votre client a déjà payé la livraison sur votre site : c\'est vous qui réglez DEM.', 'dem-livraison' ),
			),
			array(
				'title'   => __( 'Commande terminée', 'dem-livraison' ),
				'id'      => 'dem_livraison_complete_on_delivered',
				'type'    => 'checkbox',
				'default' => 'yes',
				'desc'    => __( 'Passer la commande à « Terminée » quand DEM a livré.', 'dem-livraison' ),
			),
			array(
				'title'    => __( 'Prix de secours', 'dem-livraison' ),
				'id'       => 'dem_livraison_fallback_price',
				'type'     => 'number',
				'default'  => '',
				'desc_tip' => __( 'Affiché au panier si DEM ne peut pas calculer le prix (adresse introuvable, service indisponible). Vide : la livraison DEM n\'est pas proposée dans ce cas.', 'dem-livraison' ),
				'custom_attributes' => array( 'min' => 0, 'step' => 50 ),
			),
			array(
				'title'   => __( 'Journal détaillé', 'dem-livraison' ),
				'id'      => 'dem_livraison_debug',
				'type'    => 'checkbox',
				'default' => 'no',
				'desc'    => __( 'Noter chaque appel à DEM (WooCommerce › État › Journaux). La clé n\'y figure jamais.', 'dem-livraison' ),
			),
			array( 'type' => 'sectionend', 'id' => 'dem_livraison_livraisons' ),
		);
	}

	public static function render() {
		self::render_status();
		woocommerce_admin_fields( self::fields() );
	}

	public static function save() {
		woocommerce_update_options( self::fields() );
		delete_transient( 'dem_livraison_me' );
		delete_transient( 'dem_livraison_stores' );
		self::check_connection();
		self::remember_store();
	}

	// ── Connexion ────────────────────────────────────────────────────────────

	/** Résultat de GET /v1/me, gardé 12 h. */
	public static function check_connection() {
		$cached = get_transient( 'dem_livraison_me' );
		if ( false !== $cached ) {
			return $cached;
		}
		if ( '' === DEM_Livraison_API::key() ) {
			return array( 'ok' => false, 'message' => __( 'Aucune clé enregistrée.', 'dem-livraison' ) );
		}
		$me = DEM_Livraison_API::request( 'GET', '/me' );
		$result = is_wp_error( $me )
			? array( 'ok' => false, 'message' => DEM_Livraison_API::describe( $me ) )
			: array( 'ok' => true, 'me' => $me );
		set_transient( 'dem_livraison_me', $result, $result['ok'] ? 12 * HOUR_IN_SECONDS : 5 * MINUTE_IN_SECONDS );
		return $result;
	}

	/** Points de retrait du compte (GET /v1/stores), gardés 1 h. */
	public static function stores() {
		if ( '' === DEM_Livraison_API::key() ) {
			return array();
		}
		$cached = get_transient( 'dem_livraison_stores' );
		if ( false !== $cached ) {
			return $cached;
		}
		$res    = DEM_Livraison_API::request( 'GET', '/stores' );
		$stores = ( ! is_wp_error( $res ) && isset( $res['data'] ) ) ? $res['data'] : array();
		set_transient( 'dem_livraison_stores', $stores, HOUR_IN_SECONDS );
		return $stores;
	}

	/**
	 * Point de départ des devis du panier : celui choisi, sinon le point par
	 * défaut du compte. Gardé en option : le panier n'appelle pas /stores.
	 */
	public static function remember_store() {
		$chosen = get_option( 'dem_livraison_store_id', '' );
		$store  = null;
		foreach ( self::stores() as $s ) {
			if ( ( '' === $chosen && ! empty( $s['is_default'] ) ) || $s['id'] === $chosen ) {
				$store = $s;
				break;
			}
		}
		if ( ! $store ) {
			$all   = self::stores();
			$store = $chosen ? null : ( $all ? $all[0] : null );
		}
		update_option( 'dem_livraison_store', $store, false );
	}

	public static function pickup_store() {
		$store = get_option( 'dem_livraison_store', null );
		return is_array( $store ) && isset( $store['latitude'], $store['longitude'] ) && null !== $store['latitude'] ? $store : null;
	}

	// ── Webhooks ─────────────────────────────────────────────────────────────

	public static function webhook_url() {
		return rest_url( 'dem/v1/webhook' );
	}

	/** Déclare (ou vérifie) l'adresse webhook de la boutique auprès de DEM. */
	public static function connect_webhook() {
		if ( ! current_user_can( 'manage_woocommerce' ) || ! check_admin_referer( 'dem_livraison_connect_webhook' ) ) {
			wp_die( esc_html__( 'Action non autorisée.', 'dem-livraison' ) );
		}
		$back = admin_url( 'admin.php?page=wc-settings&tab=' . self::TAB );

		$existing = get_option( 'dem_livraison_webhook_id', '' );
		if ( $existing ) {
			$res = DEM_Livraison_API::request( 'GET', '/webhooks/' . rawurlencode( $existing ) );
			if ( ! is_wp_error( $res ) && $res['url'] === self::webhook_url() ) {
				self::flash( 'success', __( 'Les webhooks sont déjà branchés.', 'dem-livraison' ) );
				wp_safe_redirect( $back );
				exit;
			}
			if ( ! is_wp_error( $res ) ) {
				DEM_Livraison_API::request( 'DELETE', '/webhooks/' . rawurlencode( $existing ) );
			}
		}

		$res = DEM_Livraison_API::request( 'POST', '/webhooks', array(
			'url'         => self::webhook_url(),
			'events'      => self::WEBHOOK_EVENTS,
			'description' => 'WooCommerce — ' . wp_parse_url( home_url(), PHP_URL_HOST ),
		) );
		if ( is_wp_error( $res ) ) {
			self::flash( 'error', __( 'Branchement impossible : ', 'dem-livraison' ) . DEM_Livraison_API::describe( $res ) );
		} else {
			update_option( 'dem_livraison_webhook_id', $res['id'], false );
			update_option( 'dem_livraison_webhook_secret', $res['secret'], false );
			self::flash( 'success', __( 'Webhooks branchés : vos commandes seront mises à jour à chaque étape de la livraison.', 'dem-livraison' ) );
		}
		wp_safe_redirect( $back );
		exit;
	}

	// ── Affichage de l'état ─────────────────────────────────────────────────

	private static function flash( $type, $message ) {
		set_transient( 'dem_livraison_flash_' . get_current_user_id(), array( $type, $message ), 60 );
	}

	private static function render_status() {
		$flash = get_transient( 'dem_livraison_flash_' . get_current_user_id() );
		if ( $flash ) {
			delete_transient( 'dem_livraison_flash_' . get_current_user_id() );
			printf( '<div class="notice notice-%s inline"><p>%s</p></div>', esc_attr( $flash[0] ), esc_html( $flash[1] ) );
		}

		echo '<h2>' . esc_html__( 'DEM Livraison', 'dem-livraison' ) . '</h2>';
		echo '<table class="form-table"><tbody>';

		// Connexion
		$status = self::check_connection();
		echo '<tr><th>' . esc_html__( 'État', 'dem-livraison' ) . '</th><td>';
		if ( $status['ok'] ) {
			$me    = $status['me'];
			$env   = 'test' === $me['api_key']['environment'];
			$label = $env ? __( 'Mode test — aucune vraie course', 'dem-livraison' ) : __( 'Production — vraies livraisons', 'dem-livraison' );
			printf(
				'<span style="color:#008a20;font-weight:600">● %s</span> — %s <mark style="background:%s;padding:2px 8px;margin-left:6px">%s</mark>',
				esc_html__( 'Connecté', 'dem-livraison' ),
				esc_html( $me['organization']['name'] ),
				$env ? '#efe6ff' : '#e5f6fd',
				esc_html( $label )
			);
			$missing = array_diff( self::NEEDED_SCOPES, (array) $me['api_key']['scopes'] );
			if ( $missing ) {
				echo '<p style="color:#b32d2e">' . esc_html__( 'Droits manquants sur cette clé : ', 'dem-livraison' ) . esc_html( implode( ', ', $missing ) ) . '</p>';
			}
		} else {
			printf( '<span style="color:#b32d2e;font-weight:600">● %s</span> — %s', esc_html__( 'Non connecté', 'dem-livraison' ), esc_html( $status['message'] ) );
		}
		echo '</td></tr>';

		// Webhooks
		echo '<tr><th>' . esc_html__( 'Webhooks', 'dem-livraison' ) . '</th><td>';
		$connected = (bool) get_option( 'dem_livraison_webhook_id', '' );
		if ( 0 !== strpos( self::webhook_url(), 'https://' ) ) {
			echo '<p style="color:#b32d2e">' . esc_html__( 'Votre boutique doit être en https pour recevoir les mises à jour de DEM.', 'dem-livraison' ) . '</p>';
		}
		echo $connected
			? '<span style="color:#008a20">● ' . esc_html__( 'Branchés', 'dem-livraison' ) . '</span> '
			: '<span style="color:#996800">● ' . esc_html__( 'Pas encore branchés', 'dem-livraison' ) . '</span> ';
		if ( $status['ok'] ) {
			printf(
				'<a class="button" href="%s">%s</a>',
				esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=dem_livraison_connect_webhook' ), 'dem_livraison_connect_webhook' ) ),
				$connected ? esc_html__( 'Vérifier', 'dem-livraison' ) : esc_html__( 'Brancher les webhooks', 'dem-livraison' )
			);
		}
		echo '<p class="description">' . esc_html( self::webhook_url() ) . '</p></td></tr>';

		// Mode de livraison
		echo '<tr><th>' . esc_html__( 'Au panier', 'dem-livraison' ) . '</th><td><p class="description">';
		printf(
			/* translators: %s: lien vers les zones de livraison */
			esc_html__( 'Ajoutez « Livraison DEM » à votre zone de livraison Sénégal : %s.', 'dem-livraison' ),
			'<a href="' . esc_url( admin_url( 'admin.php?page=wc-settings&tab=shipping' ) ) . '">' . esc_html__( 'Zones de livraison', 'dem-livraison' ) . '</a>'
		);
		echo '</p></td></tr></tbody></table>';
	}
}
